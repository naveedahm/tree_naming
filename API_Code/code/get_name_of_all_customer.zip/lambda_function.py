import json
#!/usr/bin/python
import sys
import logging
import rds_config
import pymysql

rds_host  = rds_config.db_endpoint
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name
port = 3306

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    '''conn = pymysql.connect(rds_host, user=name,
                           passwd=password, db=db_name, connect_timeout=6000)
    '''                       
    conn = pymysql.connect(
        host='database-3.ctjq5ulwjvv8.us-west-2.rds.amazonaws.com',
        user='root', 
        password = "rootuser",
        db='tree_database'
        )                           
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
def lambda_handler(event, context):
    # TODO implement

    sql_query = "select * from customers"

    lock_table_sql = "LOCK TABLES customers WRITE;"
    unlock_table_sql = "UNLOCK TABLES;"

    cur = conn.cursor()

    cur.execute(lock_table_sql)
    cur.execute(sql_query)
    output = cur.fetchall()

    cur.execute(unlock_table_sql)

    print(output)    
    
    return {
        'result':json.dumps(output),
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
