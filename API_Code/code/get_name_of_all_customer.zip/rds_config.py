#!/usr/bin/python
#config file containing credentials for rds mysql instance
db_username = "root"
db_password = "rootuser"
db_name = "tree_database"
db_endpoint = "database-3.ctjq5ulwjvv8.us-west-2.rds.amazonaws.com"