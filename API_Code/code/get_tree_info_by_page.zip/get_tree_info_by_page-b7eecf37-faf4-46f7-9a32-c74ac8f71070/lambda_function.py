import json
#!/usr/bin/python
import sys
import logging
import rds_config
import pymysql

rds_host  = rds_config.db_endpoint
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name
port = 3306

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name,
                           passwd=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")

def lambda_handler(event, context):
    # TODO implement

    page_number = 0
    items_per_page = 10

    sql_query = "select * from tree_data limit "
    sql_query = sql_query + (page_number * items_per_page)
    sql_query = sql_query + "," + items_per_page

    with conn.cursor() as cur:
        cur.execute(sql_query)


    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
